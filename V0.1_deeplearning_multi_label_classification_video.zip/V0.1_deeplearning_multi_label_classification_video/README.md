# Vdeeplearning_multi_label_classification_video_v0.1

Deeplearning_multi_label_classification_video.

# References

https://github.com/yangboz/AI-Challenge-RTVC